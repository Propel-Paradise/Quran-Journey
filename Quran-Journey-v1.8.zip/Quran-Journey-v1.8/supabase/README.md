# Quran Journey v1.8: going live

v1.8 moves every sensitive action (sign-up, payments, cancelling, adding or removing parents, emails) onto the server and locks the database so the browser can only touch what each person is allowed to see. The new website **will not work until the server pieces below are in place**, and the old website stops working once step 6 runs. Do steps 1 to 4 first (no effect on the live site), then **steps 5, 6 and 7 back to back** in one sitting (about 15 minutes; parent emails pause between 5 and 7).

You need the Supabase CLI for step 5: `npm install -g supabase`, then `supabase login` and `supabase link --project-ref fdibhjmbabdcphldnvmq` from this repo folder.

## 1. Back up
Supabase dashboard → Database → Backups. Confirm there is a recent backup (or download one).
Also copy the code of your current `send-notification` function (Edge Functions → send-notification) somewhere safe; step 5 replaces it.

## 2a. Check for leftovers from the open-database period
The old pages let any browser write to `users` and `students`. Run these in the SQL editor and look for anything you don't recognise:
```sql
-- Who has admin? Should be only you.
select id, name, email from public.users where role = 'admin';

-- Teachers whose email isn't their school's email (fine if you added extra teachers yourself)
select u.id, u.name, u.email, o.name as school, o.email as school_email
from public.users u join public.organizations o on o.id = u.org_id
where u.role = 'teacher' and lower(u.email) <> lower(o.email);

-- Parent emails on students with no matching parent account
select s.id, s.name, e as parent_email
from public.students s, unnest(s.parent_emails) e
where not exists (select 1 from public.users u where lower(u.email) = lower(e));

-- Emails that differ only by capital letters (the migration stops if any exist)
select lower(email), count(*) from public.users group by 1 having count(*) > 1;
```
Delete or fix anything unexpected before continuing.

## 2b. Make sure the admin account has the admin role
The admin page now checks `role = 'admin'` instead of a hardcoded email. In the SQL editor:
```sql
select email, role from public.users where role = 'admin';
```
If your admin email is not listed:
```sql
update public.users set role = 'admin' where email = 'your-admin-email@example.com';
```

## 3. Auth settings (Authentication → Sign In / Providers, and URL Configuration)
- **Confirm email: ON.**
- New sign-ups (parents joining with a code, new schools after payment, parents added by a teacher) no longer choose a password on the form. They get Supabase's **Invite user** email, and its link opens the set-password page. This proves they own the email.
- **Redirect URLs** must include:
  - `https://propel-paradise.github.io/Quran-Journey/index.html`
  - `https://propel-paradise.github.io/Quran-Journey/reset-password.html`
- **Custom SMTP** (Authentication → Emails → SMTP settings): Supabase's built-in email only sends a few emails per hour. Invites and password resets go through it, so point it at Resend's SMTP (smtp.resend.com, user `resend`, password = your Resend API key).
- Recommended: edit the **Invite user** email template (Authentication → Emails) to say "Set your Quran Journey password" instead of the default "You have been invited".

## 4. Secrets (Edge Functions → Secrets)
| Name | Value |
|---|---|
| `STRIPE_SECRET_KEY` | Probably already set for `create-checkout-session`. `sk_live_…` for real payments. |
| `RESEND_API_KEY` | Probably already set. |
| `NOTIFY_FROM_EMAIL` | **New.** Sender for parent emails, e.g. `Quran Journey <updates@yourdomain.com>`. Use the same sender your current `send-notification` uses. |
| `SITE_URL` | `https://propel-paradise.github.io/Quran-Journey` |
| `STRIPE_PRICE_ID` | Optional but recommended: your $19.99 plan's price id (`price_…`). Registration then only accepts checkouts for that plan. |

## 5. Deploy the edge functions
```bash
supabase functions deploy public-signup account send-notification
```
`config.toml` turns off the gateway JWT check for these three; each function checks the caller itself.
`create-checkout-session` and your Stripe webhook are unchanged.

## 6. Run the database migration
Open `supabase/migrations/20261101000000_v18_security.sql`, paste it into the SQL editor and run it. It runs as one transaction, so if anything fails nothing changes. It:
- lowercases emails, deletes the plain-text `temp_password` column, adds Stripe id columns
- replaces all row-level security rules on `users`, `organizations`, `students`, `progress_logs`
- adds small lookup functions the sign-up and reactivate pages use

## 7. Publish the website
GitHub → repo Settings → Pages → change the branch from `v1.7` to `v.18` → Save. The site updates within a few minutes.
(Or merge `v.18` into `v1.7`. Note: switching back to `v1.7` after step 6 will not restore the old site, because the old pages rely on the open database rules that step 6 removes.)

## 8. Test on your phone (10 minutes)
1. Sign in as a school. Students, parents, logs and stats load.
2. Add a parent with your second email. The email arrives; its link lets you set a password and lands on the parent page.
3. Log a session for a student linked to that parent. The parent email arrives.
4. Join as a parent with the invite code (no password on the form). The set-password email arrives and works.
5. In a private window, open `register.html?step=account&session_id=cs_test_fake`, fill the form, and confirm it refuses ("Payment session not found").
6. With a Stripe **test** school: Settings → Cancel subscription. In Stripe, the subscription shows Canceled. If the school's subscription can't be found in Stripe, cancelling refuses and changes nothing; from the admin page you can override after checking Stripe yourself.
7. Signed out, open the browser console on the sign-in page and run
   `await db.from('users').select('email').limit(1)`. It must return an error or an empty list.

## Known limits
- The join page and the parent email can be used to send email to any address (by someone with an invite code, or a teacher). Supabase's and Resend's own sending limits cap this; add a rate limit if it is ever abused.

## Check your Stripe webhook
When a cancelled school pays again on `reactivate.html`, the webhook must set the organization **and its users** back to `is_active = true`. Cancelling sets both to false.
