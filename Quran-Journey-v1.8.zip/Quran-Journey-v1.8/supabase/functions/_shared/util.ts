// Shared helpers for Quran Journey edge functions.
import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2.118.0";

export const SITE_URL = (Deno.env.get("SITE_URL") || "https://propel-paradise.github.io/Quran-Journey").replace(/\/$/, "");

export const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") || "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

// Wraps a handler with CORS + JSON error handling.
export function serve(handler: (req: Request) => Promise<Response>) {
  Deno.serve(async (req) => {
    if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
    try {
      return await handler(req);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error(e);
      return json({ error: "Something went wrong. Please try again." }, 500);
    }
  });
}

// Supabase injects either the legacy single keys or JSON maps of the new keys.
function envKey(single: string, map: string): string {
  const direct = Deno.env.get(single);
  if (direct) return direct;
  const raw = Deno.env.get(map);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      const first = Array.isArray(parsed) ? parsed[0] : Object.values(parsed)[0];
      if (typeof first === "string") return first;
    } catch { /* fall through */ }
  }
  throw new Error(`Missing ${single}`);
}

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;

export function adminClient(): SupabaseClient {
  return createClient(SUPABASE_URL, envKey("SUPABASE_SERVICE_ROLE_KEY", "SUPABASE_SECRET_KEYS"), {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export function publicClient(): SupabaseClient {
  return createClient(SUPABASE_URL, envKey("SUPABASE_ANON_KEY", "SUPABASE_PUBLISHABLE_KEYS"), {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export type UserRow = {
  id: number; name: string; email: string; role: string;
  org_id: number | null; is_active: boolean | null; must_change_password: boolean | null;
};
export type OrgRow = {
  id: number; name: string; email: string; plan: string | null; is_active: boolean | null;
  stripe_customer_id?: string | null; stripe_subscription_id?: string | null;
};

// Identifies the signed-in caller from their access token. Throws 401 if not signed in.
export async function getCaller(req: Request, db: SupabaseClient) {
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  if (!token) throw new HttpError(401, "Please sign in again.");
  const { data, error } = await db.auth.getUser(token);
  if (error || !data?.user?.email) throw new HttpError(401, "Please sign in again.");
  const email = data.user.email.toLowerCase();
  const { data: row } = await db.from("users").select("*").eq("email", email).maybeSingle();
  if (!row) throw new HttpError(403, "Account not found.");
  let org: OrgRow | null = null;
  if (row.org_id != null) {
    const { data: o } = await db.from("organizations").select("*").eq("id", row.org_id).maybeSingle();
    org = o;
  }
  return { authUser: data.user, row: row as UserRow, org };
}

// Active teacher of an active school, or throws.
export function requireTeacher(c: { row: UserRow; org: OrgRow | null }) {
  if (c.row.role !== "teacher" || c.row.is_active === false || !c.org || c.org.is_active === false) {
    throw new HttpError(403, "Only active school accounts can do this.");
  }
  return c.org;
}

export async function readBody(req: Request): Promise<Record<string, unknown>> {
  try { return await req.json(); } catch { throw new HttpError(400, "Invalid request."); }
}

export function str(v: unknown, max = 200): string {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

export function normEmail(v: unknown): string {
  const e = str(v, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new HttpError(400, "Please enter a valid email.");
  return e;
}

export function escapeHtml(v: unknown): string {
  return String(v ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

// Finds the login account id for an email (needs the auth_user_id_by_email SQL function).
export async function authUserId(db: SupabaseClient, email: string): Promise<string | null> {
  const { data, error } = await db.rpc("auth_user_id_by_email", { p_email: email });
  if (error) throw error;
  return (data as string | null) || null;
}

// ── Stripe (plain REST, no SDK) ───────────────────────────────
export async function stripe(path: string, method = "GET", params?: Record<string, string>) {
  const key = Deno.env.get("STRIPE_SECRET_KEY");
  if (!key) throw new Error("STRIPE_SECRET_KEY is not set");
  const qs = params ? new URLSearchParams(params).toString() : "";
  const url = `https://api.stripe.com/v1/${path}${method === "GET" && qs ? `?${qs}` : ""}`;
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${key}`,
      ...(method !== "GET" && qs ? { "Content-Type": "application/x-www-form-urlencoded" } : {}),
    },
    body: method !== "GET" && qs ? qs : undefined,
  });
  const body = await res.json();
  if (!res.ok) throw new Error(body?.error?.message || `Stripe error ${res.status}`);
  return body;
}

const LIVE_STATUSES = new Set(["active", "trialing", "past_due", "unpaid", "incomplete"]);

// Cancels every live Stripe subscription for a school.
// `matched` counts every subscription found for the school (any status). Zero means Stripe
// has no record we can tie to this school, so the caller must not report billing as stopped.
export async function cancelStripeBilling(org: OrgRow): Promise<{ cancelled: number; matched: number }> {
  const subIds = new Set<string>();
  if (org.stripe_subscription_id) subIds.add(org.stripe_subscription_id);

  const customerIds = new Set<string>();
  if (org.stripe_customer_id) customerIds.add(org.stripe_customer_id);
  if (org.email) {
    const customers = await stripe("customers", "GET", { email: org.email, limit: "20" });
    for (const c of customers.data || []) customerIds.add(c.id);
  }
  for (const cid of customerIds) {
    const subs = await stripe("subscriptions", "GET", { customer: cid, status: "all", limit: "50" });
    for (const s of subs.data || []) subIds.add(s.id);
  }

  let cancelled = 0, matched = 0;
  for (const id of subIds) {
    let s;
    try {
      s = await stripe(`subscriptions/${id}`);
    } catch (e) {
      if (String((e as Error).message).includes("No such subscription")) continue;
      throw e;
    }
    matched++;
    if (!LIVE_STATUSES.has(s.status)) continue;
    await stripe(`subscriptions/${id}`, "DELETE");
    cancelled++;
  }
  return { cancelled, matched };
}

// ── Email (Resend) ────────────────────────────────────────────
export async function sendEmail(to: string[], subject: string, html: string) {
  const key = Deno.env.get("RESEND_API_KEY");
  const from = Deno.env.get("NOTIFY_FROM_EMAIL");
  if (!key || !from) throw new Error("RESEND_API_KEY or NOTIFY_FROM_EMAIL is not set");
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to, subject, html }),
  });
  if (!res.ok) throw new Error(`Resend error ${res.status}: ${await res.text()}`);
}

export function emailShell(title: string, inner: string): string {
  return `<!doctype html><html><body style="margin:0;padding:24px;background:#f4f3ef;font-family:Arial,Helvetica,sans-serif;color:#1a1f1c">
  <div style="max-width:520px;margin:0 auto;background:#fff;border:1px solid #eceae5;border-radius:10px;padding:24px">
    <div style="font-weight:700;color:#047857;font-size:14px;margin-bottom:12px">Quran Journey</div>
    <h1 style="font-size:18px;margin:0 0 12px">${escapeHtml(title)}</h1>
    ${inner}
  </div></body></html>`;
}
