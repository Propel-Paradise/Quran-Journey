// Emails a student's parents after a teacher logs a session.
// The browser sends only { log_id }. Everything else is read from the database here,
// and only a teacher of that student's school can trigger it.
import {
  adminClient, emailShell, escapeHtml, getCaller, HttpError, json, readBody,
  requireTeacher, sendEmail, serve, SITE_URL,
} from "../_shared/util.ts";

serve(async (req) => {
  const body = await readBody(req);
  const logId = Number(body.log_id);
  if (!Number.isFinite(logId)) throw new HttpError(400, "Missing log_id.");

  const db = adminClient();
  const org = requireTeacher(await getCaller(req, db));

  const { data: log } = await db.from("progress_logs").select("*").eq("id", logId).maybeSingle();
  if (!log) throw new HttpError(404, "Log not found.");
  const { data: student } = await db.from("students").select("*").eq("id", log.student_id).maybeSingle();
  if (!student || student.org_id !== org.id) throw new HttpError(403, "Not your student.");

  const to: string[] = (student.parent_emails || []).filter((e: string) => /@/.test(e));
  if (to.length === 0) return json({ ok: true, sent: 0 });

  const date = new Date(`${log.date}T12:00:00`).toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric", year: "numeric",
  });
  const quality = (failed: boolean, q: string | null) => failed ? "Failed" : (q || "");
  const sabqi = [log.sabqi_juz ? `Juz ${log.sabqi_juz}` : "", log.sabqi_pages ? `${log.sabqi_pages} pages` : ""].filter(Boolean).join(", ");
  const manzil = [
    log.manzil_pages != null ? `${log.manzil_pages}${log.manzil_fraction ? " " + log.manzil_fraction : ""} Juz`
      : (log.manzil_fraction ? `${log.manzil_fraction} Juz` : ""),
    log.manzil_juz || "",
  ].filter(Boolean).join(", ");

  const rows: [string, string, string][] = [
    ["Sabaq", log.sabaq_lines ? `${log.sabaq_lines} lines` : "", quality(log.sabaq_failed, log.sabaq_quality)],
    ["Sabqi", sabqi, quality(log.sabqi_failed, log.sabqi_quality)],
    ["Manzil", manzil, quality(log.manzil_failed, log.manzil_quality)],
    ["Behavior", "", log.behavior || ""],
  ];
  const table = rows
    .filter(([, amount, q]) => amount || q)
    .map(([label, amount, q]) => `<tr>
      <td style="padding:8px 10px;border-bottom:1px solid #eceae5;font-weight:600;font-size:13px">${label}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #eceae5;font-size:13px">${escapeHtml(amount) || "—"}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #eceae5;font-size:13px;color:${q === "Failed" || q === "Needs Work" ? "#b91c1c" : q === "Good" ? "#b45309" : "#047857"}">${escapeHtml(q)}</td>
    </tr>`).join("");

  const notes = log.teacher_notes
    ? `<div style="margin-top:14px;background:#fffbeb;border:1px solid #fef3c7;border-radius:6px;padding:10px 12px;font-size:13px;line-height:1.5"><b>Teacher's note:</b> ${escapeHtml(log.teacher_notes)}</div>`
    : "";

  const html = emailShell(`${student.name}'s progress, ${date}`, `
    <p style="font-size:13px;color:#555;margin:0 0 12px">${escapeHtml(org.name)}</p>
    <table style="width:100%;border-collapse:collapse;border:1px solid #eceae5;border-radius:6px">${table}</table>
    ${notes}
    <p style="margin-top:18px"><a href="${SITE_URL}/index.html" style="color:#047857;font-size:13px">View all progress</a></p>`);

  await sendEmail(to, `${student.name}'s Quran progress: ${date}`, html);
  return json({ ok: true, sent: to.length });
});
