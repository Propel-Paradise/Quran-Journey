// Account actions for signed-in users. The caller is identified from their login token.
//   invite_parent        teacher adds a parent; Supabase emails them a link to set a password
//   remove_parent        teacher removes a parent from their school (record + login)
//   delete_account       parent deletes their own account (record + login)
//   cancel_subscription  teacher cancels their school; admin can cancel any school (org_id)
//                        Stripe billing is cancelled first, then the school is deactivated.
import {
  adminClient, authUserId, cancelStripeBilling, getCaller, HttpError, json, normEmail,
  readBody, requireTeacher, serve, SITE_URL, str,
} from "../_shared/util.ts";
import type { SupabaseClient } from "npm:@supabase/supabase-js@2.118.0";

serve(async (req) => {
  const body = await readBody(req);
  const db = adminClient();
  const caller = await getCaller(req, db);
  switch (str(body.action, 40)) {
    case "invite_parent": return await inviteParent(db, caller, body);
    case "remove_parent": return await removeParent(db, caller, body);
    case "delete_account": return await deleteAccount(db, caller);
    case "cancel_subscription": return await cancelSubscription(db, caller, body);
    default: throw new HttpError(400, "Unknown action.");
  }
});

type Caller = Awaited<ReturnType<typeof getCaller>>;

async function inviteParent(db: SupabaseClient, caller: Caller, body: Record<string, unknown>) {
  const org = requireTeacher(caller);
  const name = str(body.name, 100);
  const email = normEmail(body.email);
  if (!name) throw new HttpError(400, "Please fill in both fields.");

  const { data: existing } = await db.from("users").select("id").eq("email", email).maybeSingle();
  if (existing || await authUserId(db, email)) throw new HttpError(409, "A user with this email already exists.");

  const { data: invited, error: invErr } = await db.auth.admin.inviteUserByEmail(email, {
    redirectTo: `${SITE_URL}/reset-password.html`,
    data: { name },
  });
  if (invErr || !invited?.user) throw new HttpError(400, invErr?.message || "Could not send the invite.");

  const { error: rowErr } = await db.from("users").insert({
    name, email, role: "parent", org_id: org.id, is_active: true, must_change_password: false,
  });
  if (rowErr) {
    await db.auth.admin.deleteUser(invited.user.id);
    throw rowErr;
  }
  return json({ ok: true });
}

// Removes an email from parent_emails on the given students.
async function unlinkParent(db: SupabaseClient, email: string, orgId?: number) {
  let q = db.from("students").select("id,parent_emails").contains("parent_emails", [email]);
  if (orgId != null) q = q.eq("org_id", orgId);
  const { data: students, error } = await q;
  if (error) throw error;
  for (const s of students || []) {
    const updated = (s.parent_emails || []).filter((e: string) => e.toLowerCase() !== email);
    const { error: upErr } = await db.from("students").update({ parent_emails: updated }).eq("id", s.id);
    if (upErr) throw upErr;
  }
}

async function deleteLogin(db: SupabaseClient, email: string) {
  const id = await authUserId(db, email);
  if (id) {
    const { error } = await db.auth.admin.deleteUser(id);
    if (error) throw error;
  }
}

async function removeParent(db: SupabaseClient, caller: Caller, body: Record<string, unknown>) {
  const org = requireTeacher(caller);
  const email = normEmail(body.email);
  const { data: parent } = await db.from("users").select("*").eq("email", email).maybeSingle();
  if (!parent || parent.role !== "parent" || parent.org_id !== org.id) {
    throw new HttpError(404, "Parent not found in your school.");
  }
  await unlinkParent(db, email, org.id);
  const { error } = await db.from("users").delete().eq("id", parent.id);
  if (error) throw error;
  await deleteLogin(db, email);
  return json({ ok: true });
}

async function deleteAccount(db: SupabaseClient, caller: Caller) {
  if (caller.row.role !== "parent") {
    throw new HttpError(403, "School accounts are closed from Settings → Cancel subscription.");
  }
  const email = caller.row.email.toLowerCase();
  await unlinkParent(db, email);
  const { error } = await db.from("users").delete().eq("id", caller.row.id);
  if (error) throw error;
  const { error: authErr } = await db.auth.admin.deleteUser(caller.authUser.id);
  if (authErr) throw authErr;
  return json({ ok: true });
}

async function cancelSubscription(db: SupabaseClient, caller: Caller, body: Record<string, unknown>) {
  let orgId: number;
  if (caller.row.role === "admin" && caller.row.is_active !== false && body.org_id != null) {
    orgId = Number(body.org_id);
    if (!Number.isFinite(orgId)) throw new HttpError(400, "Invalid school.");
  } else {
    orgId = requireTeacher(caller).id;
  }

  const { data: org } = await db.from("organizations").select("*").eq("id", orgId).maybeSingle();
  if (!org) throw new HttpError(404, "School not found.");

  // Stop billing first. If Stripe fails, nothing is deactivated, so the school is never
  // shown as cancelled while still being charged.
  let result;
  try {
    result = await cancelStripeBilling(org);
  } catch (e) {
    console.error("Stripe cancel failed", e);
    throw new HttpError(502, "Could not cancel billing with Stripe. Nothing was changed. Please try again.");
  }
  // No subscription found for this school: don't claim billing stopped.
  // An admin who has checked Stripe by hand can pass force: true.
  const isAdmin = caller.row.role === "admin";
  if (result.matched === 0 && org.plan !== "cancelled" && !(isAdmin && body.force === true)) {
    throw new HttpError(409, isAdmin
      ? "No Stripe subscription found for this school's email. Check Stripe, then deactivate with force."
      : "We couldn't find your subscription in our billing system, so nothing was changed. Please contact support and we'll cancel it for you.");
  }

  const { error: oErr } = await db.from("organizations").update({ is_active: false, plan: "cancelled" }).eq("id", orgId);
  if (oErr) throw oErr;
  const { error: uErr } = await db.from("users").update({ is_active: false }).eq("org_id", orgId);
  if (uErr) throw uErr;

  return json({ ok: true, subscriptions_cancelled: result.cancelled });
}
