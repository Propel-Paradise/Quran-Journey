// Sign-up actions that run before the person has an account.
//   join_school           parent joins a school with an invite code
//   complete_registration school finishes sign-up after paying on Stripe Checkout
// All checks happen here on the server; the browser cannot set roles or skip payment.
// Neither action takes a password: the person gets an email link and sets their own,
// so nobody can pre-register someone else's email with a password they know.
import {
  adminClient, authUserId, HttpError, json, normEmail, readBody, serve, SITE_URL, str, stripe,
} from "../_shared/util.ts";
import type { SupabaseClient } from "npm:@supabase/supabase-js@2.118.0";

serve(async (req) => {
  const body = await readBody(req);
  const action = str(body.action, 40);
  if (action === "join_school") return await joinSchool(body);
  if (action === "complete_registration") return await completeRegistration(body);
  throw new HttpError(400, "Unknown action.");
});

// Sends Supabase's invite email; its link opens the set-password page.
async function inviteLogin(db: SupabaseClient, email: string, name: string) {
  const { data, error } = await db.auth.admin.inviteUserByEmail(email, {
    redirectTo: `${SITE_URL}/reset-password.html`,
    data: { name },
  });
  if (error || !data?.user) throw new HttpError(400, error?.message || "Could not send the email. Please try again.");
  return data.user.id;
}

function newInviteCode(): string {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  const c = Array.from(bytes, (b) => chars[b % chars.length]).join("");
  return `${c.slice(0, 4)}-${c.slice(4)}`;
}

async function joinSchool(body: Record<string, unknown>) {
  const code = str(body.code, 20).toUpperCase();
  const name = str(body.name, 100);
  const email = normEmail(body.email);
  if (!name) throw new HttpError(400, "Please enter your name.");

  const db = adminClient();
  const { data: org } = await db.from("organizations").select("id,name,is_active").eq("invite_code", code).maybeSingle();
  if (!org) throw new HttpError(400, "Invite code not found. Check with your school.");
  if (org.is_active === false) throw new HttpError(400, "This school's account is currently inactive.");

  const { data: existing } = await db.from("users").select("id").eq("email", email).maybeSingle();
  if (existing || await authUserId(db, email)) {
    throw new HttpError(409, "This email already has an account. Please sign in, or use Forgot password.");
  }

  const { error: rowErr } = await db.from("users").insert({
    name, email, role: "parent", org_id: org.id, is_active: true, must_change_password: false,
  });
  if (rowErr) throw rowErr;
  try {
    await inviteLogin(db, email, name);
  } catch (e) {
    await db.from("users").delete().eq("email", email);
    throw e;
  }
  return json({ ok: true, school: org.name });
}

const LIVE_SUB = new Set(["active", "trialing"]);
const MAX_CHECKOUT_AGE_SECONDS = 48 * 3600;

async function completeRegistration(body: Record<string, unknown>) {
  const sessionId = str(body.session_id, 200);
  const name = str(body.name, 100);
  const orgName = str(body.org_name, 120);
  if (!/^cs_(test|live)_[A-Za-z0-9]+$/.test(sessionId)) throw new HttpError(400, "Payment session not found. Please start again.");
  if (!name) throw new HttpError(400, "Please enter your name.");
  if (!orgName) throw new HttpError(400, "Please enter your organization name.");

  // 1. Confirm with Stripe that this is a finished, recent subscription checkout that is still live.
  let session;
  try {
    session = await stripe(`checkout/sessions/${sessionId}`, "GET", { "expand[]": "line_items" });
  } catch {
    throw new HttpError(400, "Payment session not found. Please start again.");
  }
  if (session.status !== "complete" || session.mode !== "subscription") {
    throw new HttpError(402, "Checkout was not completed. Please finish payment first.");
  }
  if (Date.now() / 1000 - Number(session.created) > MAX_CHECKOUT_AGE_SECONDS) {
    throw new HttpError(400, "This payment link has expired. Please contact support.");
  }
  const priceId = Deno.env.get("STRIPE_PRICE_ID");
  if (priceId && !(session.line_items?.data || []).some((li: { price?: { id?: string } }) => li.price?.id === priceId)) {
    throw new HttpError(400, "This checkout is not for a Quran Journey plan.");
  }
  const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id || null;
  const customerId = typeof session.customer === "string" ? session.customer : session.customer?.id || null;
  if (!subscriptionId) throw new HttpError(400, "No subscription on this payment. Please contact support.");
  const sub = await stripe(`subscriptions/${subscriptionId}`);
  if (!LIVE_SUB.has(sub.status)) throw new HttpError(402, "This subscription is not active. Please start again.");

  const email = String(session.customer_details?.email || session.customer_email || "").toLowerCase();
  if (!email) throw new HttpError(400, "No email on the payment. Please contact support.");

  const db = adminClient();

  // 2. Each paid checkout and each subscription can create exactly one school.
  const { data: used } = await db.from("organizations").select("id")
    .or(`stripe_checkout_session_id.eq.${sessionId},stripe_subscription_id.eq.${subscriptionId}`).limit(1);
  if (used && used.length) throw new HttpError(409, "This school is already set up. Check your email for the link to set your password.");
  const { data: sameEmail } = await db.from("organizations").select("id").eq("email", email).maybeSingle();
  if (sameEmail) throw new HttpError(409, "A school with this email already exists. Please sign in.");
  const { data: userRow } = await db.from("users").select("id").eq("email", email).maybeSingle();
  if (userRow || await authUserId(db, email)) {
    throw new HttpError(409, "This email already has an account. Please sign in, or use Forgot password.");
  }

  // 3. Create the school and the teacher record, then email the set-password link
  //    (proves the person owns the email; undone on failure).
  const { data: org, error: orgErr } = await db.from("organizations").insert({
    name: orgName, email, plan: sub.status === "trialing" ? "trial" : "pro", is_active: true,
    invite_code: newInviteCode(), stripe_customer_id: customerId,
    stripe_subscription_id: subscriptionId, stripe_checkout_session_id: sessionId,
  }).select().single();
  if (orgErr) {
    if (String(orgErr.code) === "23505") throw new HttpError(409, "This school is already set up. Check your email.");
    throw orgErr;
  }

  const { error: rowErr } = await db.from("users").insert({
    name, email, role: "teacher", org_id: org.id, is_active: true, must_change_password: false,
  });
  if (rowErr) {
    await db.from("organizations").delete().eq("id", org.id);
    throw rowErr;
  }
  try {
    await inviteLogin(db, email, name);
  } catch (e) {
    await db.from("users").delete().eq("email", email);
    await db.from("organizations").delete().eq("id", org.id);
    throw e;
  }

  return json({ ok: true, email });
}
