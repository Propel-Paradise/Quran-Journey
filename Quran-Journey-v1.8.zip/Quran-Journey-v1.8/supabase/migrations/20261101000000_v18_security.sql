-- Quran Journey v1.8 security migration
-- Run once in the Supabase SQL editor (or `supabase db push`).
-- Everything runs in one transaction: if any step fails, nothing changes.

begin;

-- ─────────────────────────────────────────────────────────────
-- 1. Normalise emails to lowercase (Supabase Auth stores them lowercase)
-- ─────────────────────────────────────────────────────────────
do $$
declare dups text;
begin
  select string_agg(lower(trim(email)), ', ') into dups
  from (select lower(trim(email)) as email from public.users group by 1 having count(*) > 1) d;
  if dups is not null then
    raise exception 'These emails appear more than once in users (differing only by capital letters): %. Merge or delete the extra rows, then run this again.', dups;
  end if;
end $$;

update public.users set email = lower(trim(email))
  where email is not null and email <> lower(trim(email));

update public.organizations set email = lower(trim(email))
  where email is not null and email <> lower(trim(email));

update public.students
  set parent_emails = coalesce(
    (select array_agg(distinct lower(trim(e))) from unnest(parent_emails) e where e is not null and trim(e) <> ''),
    '{}')
  where parent_emails is not null;

-- ─────────────────────────────────────────────────────────────
-- 2. Stop storing passwords in plain text
-- ─────────────────────────────────────────────────────────────
alter table public.users drop column if exists temp_password;

-- ─────────────────────────────────────────────────────────────
-- 3. Stripe ids on organizations (used to cancel billing)
-- ─────────────────────────────────────────────────────────────
alter table public.organizations
  add column if not exists stripe_customer_id text,
  add column if not exists stripe_subscription_id text,
  add column if not exists stripe_checkout_session_id text;

-- One school per paid checkout
create unique index if not exists organizations_stripe_checkout_session_key
  on public.organizations (stripe_checkout_session_id) where stripe_checkout_session_id is not null;

-- Invite codes: unique and in the ABCD-EF23 format.
-- If two schools share a code today, the newer one is cleared (its teacher's page makes a fresh one on next sign-in).
update public.organizations o set invite_code = null
  where invite_code is not null
    and exists (select 1 from public.organizations o2 where o2.invite_code = o.invite_code and o2.id < o.id);
create unique index if not exists organizations_invite_code_key
  on public.organizations (invite_code) where invite_code is not null;
alter table public.organizations drop constraint if exists organizations_invite_code_format;
alter table public.organizations add constraint organizations_invite_code_format
  check (invite_code is null or invite_code ~ '^[A-Z0-9]{4}-[A-Z0-9]{4}$') not valid;

-- Indexes the access rules rely on
create index if not exists users_email_idx on public.users (email);
create index if not exists users_org_id_idx on public.users (org_id);
create index if not exists students_org_id_idx on public.students (org_id);
create index if not exists progress_logs_student_id_idx on public.progress_logs (student_id);

-- ─────────────────────────────────────────────────────────────
-- 4. Deleting a student deletes their logs in the same step
--    (NOT VALID = existing rows are not re-checked, so this cannot fail on old data)
-- ─────────────────────────────────────────────────────────────
do $$
declare r record;
begin
  for r in
    select conname from pg_constraint
    where conrelid = 'public.progress_logs'::regclass
      and contype = 'f'
      and confrelid = 'public.students'::regclass
  loop
    execute format('alter table public.progress_logs drop constraint %I', r.conname);
  end loop;
end $$;

alter table public.progress_logs
  add constraint progress_logs_student_id_fkey
  foreign key (student_id) references public.students(id) on delete cascade not valid;

-- ─────────────────────────────────────────────────────────────
-- 5. Helper functions used by the rules below
-- ─────────────────────────────────────────────────────────────
create or replace function public.jwt_email() returns text
language sql stable set search_path = '' as $$
  select lower(coalesce(auth.jwt() ->> 'email', ''))
$$;

-- Role of the signed-in user, or NULL if the user (or a teacher's school) is deactivated
create or replace function public.my_role() returns text
language sql stable security definer set search_path = '' as $$
  select u.role::text
  from public.users u
  left join public.organizations o on o.id = u.org_id
  where u.email = public.jwt_email()
    and u.is_active is not false
    and (u.role <> 'teacher' or o.is_active is not false)
  limit 1
$$;

create or replace function public.my_org_id() returns bigint
language sql stable security definer set search_path = '' as $$
  select u.org_id::bigint from public.users u where u.email = public.jwt_email() limit 1
$$;

-- Role regardless of active status (lets a deactivated teacher's sign-in find their school to reactivate)
create or replace function public.my_account_role() returns text
language sql stable security definer set search_path = '' as $$
  select u.role::text from public.users u where u.email = public.jwt_email() limit 1
$$;

create or replace function public.is_admin() returns boolean
language sql stable set search_path = '' as $$
  select coalesce(public.my_role() = 'admin', false)
$$;

-- ─────────────────────────────────────────────────────────────
-- 6. Row level security: replace all existing rules on the four app tables
-- ─────────────────────────────────────────────────────────────
do $$
declare r record;
begin
  for r in
    select schemaname, tablename, policyname from pg_policies
    where schemaname = 'public'
      and tablename in ('users', 'organizations', 'students', 'progress_logs')
  loop
    execute format('drop policy %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

alter table public.users         enable row level security;
alter table public.organizations enable row level security;
alter table public.students      enable row level security;
alter table public.progress_logs enable row level security;

-- Signed-out visitors cannot read or write any app table directly.
revoke all on public.users, public.organizations, public.students, public.progress_logs from anon, authenticated;

-- users: read yourself; teachers read their school's users; admin reads all.
-- Only name and must_change_password can be changed from the browser.
-- Role, school, email and active status change only through edge functions.
grant select on public.users to authenticated;
grant update (name, must_change_password) on public.users to authenticated;

create policy users_select on public.users for select to authenticated using (
  email = (select public.jwt_email())
  or (select public.is_admin())
  or ((select public.my_role()) = 'teacher' and org_id::bigint = (select public.my_org_id()))
);

create policy users_update_self on public.users for update to authenticated
  using (email = (select public.jwt_email()))
  with check (email = (select public.jwt_email()));

-- organizations: members read their own school; admin reads all.
-- Teachers can only change the invite code. Plan and active status change only on the server.
grant select on public.organizations to authenticated;
grant update (invite_code) on public.organizations to authenticated;

create policy organizations_select on public.organizations for select to authenticated using (
  (select public.is_admin())
  or (id::bigint = (select public.my_org_id()) and (select public.my_account_role()) = 'teacher')
);

create policy organizations_update_invite on public.organizations for update to authenticated
  using ((select public.my_role()) = 'teacher' and id::bigint = (select public.my_org_id()))
  with check ((select public.my_role()) = 'teacher' and id::bigint = (select public.my_org_id()));

-- students: teachers manage their own school's students; parents read their linked children.
grant select, insert, update, delete on public.students to authenticated;

create policy students_select on public.students for select to authenticated using (
  (select public.is_admin())
  or ((select public.my_role()) = 'teacher' and org_id::bigint = (select public.my_org_id()))
  or ((select public.my_role()) = 'parent' and (select public.jwt_email()) = any(parent_emails))
);

create policy students_teacher_insert on public.students for insert to authenticated
  with check ((select public.my_role()) = 'teacher' and org_id::bigint = (select public.my_org_id()));

create policy students_teacher_update on public.students for update to authenticated
  using ((select public.my_role()) = 'teacher' and org_id::bigint = (select public.my_org_id()))
  with check ((select public.my_role()) = 'teacher' and org_id::bigint = (select public.my_org_id()));

create policy students_teacher_delete on public.students for delete to authenticated
  using ((select public.my_role()) = 'teacher' and org_id::bigint = (select public.my_org_id()));

-- progress_logs: visible to anyone who can see the student; written by that school's teachers.
grant select, insert, update, delete on public.progress_logs to authenticated;

create policy progress_logs_select on public.progress_logs for select to authenticated using (
  exists (select 1 from public.students s where s.id = student_id)
);

create policy progress_logs_teacher_insert on public.progress_logs for insert to authenticated
  with check ((select public.my_role()) = 'teacher' and exists (
    select 1 from public.students s where s.id = student_id and s.org_id::bigint = (select public.my_org_id())));

create policy progress_logs_teacher_update on public.progress_logs for update to authenticated
  using ((select public.my_role()) = 'teacher' and exists (
    select 1 from public.students s where s.id = student_id and s.org_id::bigint = (select public.my_org_id())))
  with check ((select public.my_role()) = 'teacher' and exists (
    select 1 from public.students s where s.id = student_id and s.org_id::bigint = (select public.my_org_id())));

create policy progress_logs_teacher_delete on public.progress_logs for delete to authenticated
  using ((select public.my_role()) = 'teacher' and exists (
    select 1 from public.students s where s.id = student_id and s.org_id::bigint = (select public.my_org_id())));

-- ─────────────────────────────────────────────────────────────
-- 7. Narrow lookups for signed-out pages (return only what the page needs)
-- ─────────────────────────────────────────────────────────────

-- join.html: is this invite code valid?
create or replace function public.lookup_invite_code(p_code text)
returns table(name text, is_active boolean)
language sql stable security definer set search_path = '' as $$
  select o.name::text, coalesce(o.is_active, false)
  from public.organizations o
  where o.invite_code = upper(trim(p_code))
  limit 1
$$;

-- register.html / reactivate.html: does a school exist for this email, and is it active?
create or replace function public.org_status_by_email(p_email text)
returns table(name text, email text, is_active boolean)
language sql stable security definer set search_path = '' as $$
  select * from (
    select o.name::text, o.email::text, coalesce(o.is_active, false)
    from public.organizations o
    where o.email = lower(trim(p_email))
    union all
    select o.name::text, o.email::text, coalesce(o.is_active, false)
    from public.users u join public.organizations o on o.id = u.org_id
    where u.email = lower(trim(p_email)) and u.role = 'teacher'
  ) x
  limit 1
$$;

revoke execute on function public.lookup_invite_code(text) from public;
revoke execute on function public.org_status_by_email(text) from public;
grant execute on function public.lookup_invite_code(text) to anon, authenticated;
grant execute on function public.org_status_by_email(text) to anon, authenticated;

-- school.html: latest log per student (rules above still apply)
create or replace function public.latest_logs(p_student_ids bigint[])
returns setof public.progress_logs
language sql stable set search_path = '' as $$
  select distinct on (l.student_id) l.*
  from public.progress_logs l
  where l.student_id = any(p_student_ids)
  order by l.student_id, l.date desc
$$;
revoke execute on function public.latest_logs(bigint[]) from public, anon;
grant execute on function public.latest_logs(bigint[]) to authenticated;

-- Edge functions only: find a login account id by email (to delete it)
create or replace function public.auth_user_id_by_email(p_email text)
returns uuid
language sql stable security definer set search_path = '' as $$
  select id from auth.users where lower(email) = lower(trim(p_email)) limit 1
$$;
revoke execute on function public.auth_user_id_by_email(text) from public, anon, authenticated;
grant execute on function public.auth_user_id_by_email(text) to service_role;

commit;
